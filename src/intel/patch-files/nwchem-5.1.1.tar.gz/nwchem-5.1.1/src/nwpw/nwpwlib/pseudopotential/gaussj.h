/*
 $Id: gaussj.h,v 1.1 2001/08/30 16:58:35 bylaska Exp $
*/
#ifndef _GAUSSJ_H_
#define _GAUSSJ_H_


extern	void gaussj(int, double*, int, double*);

#endif
