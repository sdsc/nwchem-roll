#ifndef _PERDEW_WANG_H_
#define _PERDEW_WANG_H_

extern void   R_Perdew_Wang();
#endif
