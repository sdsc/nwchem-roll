
/*
   $Id: paw_my_constants.c,v 1.3 2007/04/10 19:04:34 d3p708 Exp $
*/

void paw_my_constants()
{
}
