/*
 $Id: vosko.h,v 1.1 2001/08/30 16:58:38 bylaska Exp $
*/
#ifndef _VOSKO_H_
#define _VOSKO_H_

extern void   R_Vosko();
#endif
