#ifndef _revPBE96_H_
#define _revPBE96_H_

extern void   R_revPBE_Correlation();
#endif
