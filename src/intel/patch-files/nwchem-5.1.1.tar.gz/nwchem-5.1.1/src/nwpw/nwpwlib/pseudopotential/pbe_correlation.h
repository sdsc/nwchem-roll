#ifndef _PBE96_H_
#define _PBE96_H_

extern void   R_PBE96_Correlation();
#endif
