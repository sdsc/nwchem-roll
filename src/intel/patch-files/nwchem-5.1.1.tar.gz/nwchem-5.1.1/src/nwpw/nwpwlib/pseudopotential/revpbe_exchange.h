#ifndef _revPBE_EXCHANGE_H_
#define _revPBE_EXCHANGE_H_

extern void   R_revPBE_Exchange();
#endif
