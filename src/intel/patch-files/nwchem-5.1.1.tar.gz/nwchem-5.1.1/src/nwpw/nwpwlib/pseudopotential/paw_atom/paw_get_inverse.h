#ifndef	_PAW_GET_INVERSE_H_
#define _PAW_GET_INVERSE_H_
/*
   $Id: paw_get_inverse.h,v 1.2 2004/10/14 22:05:03 bylaska Exp $
*/


extern void    paw_get_inverse(double **a, int matrix_size);
extern void paw_test_matrix_inverse();

#endif
