#ifndef _PBE_EXCHANGE_H_
#define _PBE_EXCHANGE_H_

extern void   R_PBE96_Exchange();
#endif
