/*
 $Id: grids.h,v 1.1 2001/08/30 16:58:35 bylaska Exp $
*/
#ifndef _GRID_H_
#define _GRID_H_
/* grid.h
   author - Eric Bylaska
*/

extern	void	init_Grids();
extern	double	*alloc_Grid();
extern	void	dealloc_Grid(double*);

#endif
