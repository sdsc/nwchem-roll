#ifndef  _PAW_ERROR_FUNCTION_H_
#define _PAW_ERROR_FUNCTION_H_
/*
   $Id: paw_error_function.h,v 1.3 2007/04/10 19:04:34 d3p708 Exp $
*/


extern double  paw_my_erf(double x);

#endif

