#ifndef _SEMICORE_H_
#define _SEMICORE_H_

extern void   generate_rho_semicore();
#endif
