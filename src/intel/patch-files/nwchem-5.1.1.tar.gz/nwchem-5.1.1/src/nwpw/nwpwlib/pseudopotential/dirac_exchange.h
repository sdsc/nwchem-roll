/*
 $Id: dirac_exchange.h,v 1.1 2001/08/30 16:58:35 bylaska Exp $
*/
#ifndef _DIRAC_EXCHANGE_H_
#define _DIRAC_EXCHANGE_H_

extern void   set_Dirac_alpha();
extern double Dirac_alpha();
extern void   R_Dirac_Exchange();
#endif
