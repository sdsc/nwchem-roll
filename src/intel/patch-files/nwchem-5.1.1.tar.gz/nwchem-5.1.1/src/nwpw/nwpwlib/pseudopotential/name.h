/*
 $Id: name.h,v 1.2 2008/01/29 23:09:15 d3p708 Exp $
*/
#ifndef	_NAME_H_
#define _NAME_H_

extern	char * spd_Name(int);

#endif
