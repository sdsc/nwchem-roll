/*
 $Id: perdew_zunger.h,v 1.1 2001/08/30 16:58:37 bylaska Exp $
*/
#ifndef _PERDEW_ZUNGER_H_
#define _PERDEW_ZUNGER_H_

extern void   R_Perdew_Zunger();
#endif
