/*
 $Id: rappe.h,v 1.1 2002/01/21 01:22:04 bylaska Exp $
*/
#ifndef _RAPPE_H_
#define _RAPPE_H_
/* rappe.h -
   Author - Eric Bylaska

*/

void	Suggested_Param_Rappe();
void	solve_Rappe();

#endif
