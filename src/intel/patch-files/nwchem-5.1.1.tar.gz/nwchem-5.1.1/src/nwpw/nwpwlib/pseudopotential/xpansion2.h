#ifndef _GET_CS_H_
#define _GET_CS_H_
/* get_cs.h
*/

extern  void    chi_xpansion2();
extern	void	psi_xpansion2();
extern	void	dpsi_xpansion2();
extern	int	init_xpansion2(int,int,double,
                              double*, double*, double*,
                              double*, double*, double*);

#endif
