#ifndef _PAW_BYSECT_H_
#define _PAW_BYSECT_H_

/*
   $Id: paw_bisect.h,v 1.2 2004/10/14 22:05:02 bylaska Exp $
*/

extern double paw_bisection(double (*my_func)(double), double , double , double );

#endif

