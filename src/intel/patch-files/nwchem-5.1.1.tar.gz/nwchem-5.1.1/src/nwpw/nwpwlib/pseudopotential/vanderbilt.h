#ifndef _VANDERBILT_H_
#define _VANDERBILT_H_
/* vanderbilt.h -
   Author - Eric Bylaska

*/

void	Suggested_Param_Vanderbilt();
void	solve_Vanderbilt();

#endif
