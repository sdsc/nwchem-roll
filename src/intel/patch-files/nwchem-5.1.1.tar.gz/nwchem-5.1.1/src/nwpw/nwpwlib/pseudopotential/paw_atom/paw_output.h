#ifndef	_PAW_OUTPUT_H_
#define _PAW_OUTPUT_H_

/*
   $Id: paw_output.h,v 1.2 2004/10/14 22:05:03 bylaska Exp $
*/


extern void paw_generate_basis_file();

#endif


