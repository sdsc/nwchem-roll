/*
 $Id: ttt.c,v 1.1 2001/08/30 16:58:38 bylaska Exp $
*/

#include	<stdio.h>
#include	<math.h>

main()
{
   printf("%le\n",1.0/720.0);
}
