#ifndef _Becke_EXCHANGE_H_
#define _Becke_EXCHANGE_H_

extern void   R_Becke_Exchange();
#endif
