#ifndef _LYP_H_
#define _LYP_H_

extern void   R_LYP_Correlation();
#endif
