/*
 $Id: hamann.h,v 1.1 2001/08/30 16:58:36 bylaska Exp $
*/
#ifndef _HAMANN_H_
#define _HAMANN_H_
/* hamann.h -
   Author - Eric Bylaska

*/

void	Suggested_Param_Hamann();
void	solve_Hamann();

#endif
