/*
 $Id: troullier.h,v 1.1 2001/08/30 16:58:37 bylaska Exp $
*/
#ifndef _TROULLIER_H_
#define _TROULLIER_H_
/* troullier.h -
   Author - Eric Bylaska

*/

void	Suggested_Param_Troullier();
void	solve_Troullier();

#endif
