/*
 $Id: debug.h,v 1.1 2001/11/29 16:51:21 bylaska Exp $
*/
#ifndef _DEBUG_H_
#define _DEBUG_H_
/* get_word.h -
   Author - Eric Bylaska

*/

extern int debug_print();
extern void set_debug_print(int i);

#endif
