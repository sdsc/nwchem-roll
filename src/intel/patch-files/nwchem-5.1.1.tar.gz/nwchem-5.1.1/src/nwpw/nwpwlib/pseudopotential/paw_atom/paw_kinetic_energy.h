#ifndef	_PAW_KINETIC_ENERGY_H_
#define _PAW_KINETIC_ENERGY_H_
/*
   $Id: paw_kinetic_energy.h,v 1.2 2004/10/14 22:05:03 bylaska Exp $
*/


extern double paw_get_kinetic_energy(int , int*, double*, double**, double**);

#endif


