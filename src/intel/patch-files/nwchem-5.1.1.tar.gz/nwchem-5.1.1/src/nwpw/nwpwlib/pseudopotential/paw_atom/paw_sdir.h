#ifndef _PAW_SDIR_H_
#define _PAW_SDIR_H_
/*
   $Id: paw_sdir.h,v 1.1 2004/10/14 22:23:33 bylaska Exp $
*/


extern void  paw_set_debug(int debug);
extern void  paw_set_sdir(char *sdir, int m9);
extern char* paw_sdir();
extern int   paw_debug();

#endif

