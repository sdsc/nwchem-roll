/**********************************************************************\
                            ACKNOWLEDGMENT
************************************************************************
This software and its documentation were produced with Government
support under Contract Number DE-AC06-76RLO-1830 awarded by the United
States Department of Energy.  The Government retains a paid-up
non-exclusive, irrevocable worldwide license to reproduce, prepare
derivative works, perform publicly and display publicly by or for the
Government, including the right to distribute to other Government
contractors.
\**********************************************************************/
