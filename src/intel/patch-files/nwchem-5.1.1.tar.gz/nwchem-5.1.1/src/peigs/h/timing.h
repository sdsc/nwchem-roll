/* $Id: timing.h,v 1.2 1999/07/28 00:39:18 d3e129 Exp $ */
#include <time.h>

typedef struct TIMING_ {
  DoublePrecision choleski, inverse, conjug, householder, pstebz, pstein, mxm5x, mxm25, pdspevx, pdspgvx;
} TIMINGG;




