*
* $Id: mxsubs.h,v 1.2 1999/07/28 00:39:03 d3e129 Exp $
*
      common /mxscom/ me, host, nproc
      integer me, host, nproc
